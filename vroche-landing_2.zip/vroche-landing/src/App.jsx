import React, { useEffect, useMemo, useRef, useState, useCallback } from "react";

const BRAND = {
  mint: "#63D7B1",
  coral: "#FF5733",
  white: "#FCFFFE",
  black: "#040806",
};

const VROCHE_LOGO_SRC = "https://i.postimg.cc/7ZnpbB79/vroche-Blanco.png";
const VROCHE_LOGO_TEXT_SRC = "https://i.postimg.cc/0Qn4yrwr/vroche-Blanco-Texto.png";

// ─── Legal Data ──────────────────────────────────────────────────────────────
const LEGAL = {
  company: "VROCHE APP S.L.",
  cif: "B22761977",
  address: "Calle Don Abraham Quintanilla, 12, Madrid",
  email: "privacidad@info.vroche.com",
  domain: "vroche.com",
  dpo_email: "privacidad@info.vroche.com",
  aepd_url: "https://www.aepd.es",
};

// ─── Utils ────────────────────────────────────────────────────────────────────
export function clamp(value, min, max) {
  return Math.min(Math.max(value, min), max);
}
export function getFeatureCount(features) {
  return Array.isArray(features) ? features.length : 0;
}
export function getUseCaseCount(useCases) {
  return Array.isArray(useCases) ? useCases.length : 0;
}
export function isValidWaitlistEmail(value) {
  return typeof value === "string" && /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value.trim());
}
export function createLogoFieldItems(count = 120, seed = 91) {
  let current = seed;
  function random() {
    current = (current * 1664525 + 1013904223) % 4294967296;
    return current / 4294967296;
  }
  return Array.from({ length: count }, (_, index) => ({
    id: `vroche-bg-logo-${index}`,
    size: 12 + random() * 22,
    left: 2 + random() * 96,
    top: 2 + random() * 96,
    rotate: -38 + random() * 76,
    opacity: 0.035 + random() * 0.06,
    driftX: -7 + random() * 14,
    driftY: -7 + random() * 14,
    duration: 12 + random() * 10,
    delay: random() * 8,
  }));
}
export function calculateLogoRotation(pointerX, pointerY, rect, viewportWidth = 1440, viewportHeight = 900) {
  if (!rect) return { rotateX: 0, rotateY: 0, shineX: 50, shineY: 50 };
  const centerX = rect.left + rect.width / 2;
  const centerY = rect.top + rect.height / 2;
  const dx = pointerX - centerX;
  const dy = pointerY - centerY;
  return {
    rotateX: clamp((-dy / Math.max(viewportHeight * 0.3, 1)) * 24, -28, 28),
    rotateY: clamp((dx / Math.max(viewportWidth * 0.32, 1)) * 26, -30, 30),
    shineX: clamp(((pointerX - rect.left) / Math.max(rect.width, 1)) * 100, 0, 100),
    shineY: clamp(((pointerY - rect.top) / Math.max(rect.height, 1)) * 100, 0, 100),
  };
}

const SCATTERED_LOGOS = createLogoFieldItems(120, 91);

// ─── Icons ────────────────────────────────────────────────────────────────────
function IconBase({ children, className = "h-5 w-5" }) {
  return (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"
      strokeLinecap="round" strokeLinejoin="round" className={className} aria-hidden="true">
      {children}
    </svg>
  );
}
const ArrowRightIcon = ({ className }) => (<IconBase className={className}><path d="M5 12h14" /><path d="M13 6l6 6-6 6" /></IconBase>);
const CameraIcon = ({ className }) => (<IconBase className={className}><path d="M4 7h3l2-2h6l2 2h3a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V9a2 2 0 0 1 2-2z" /><circle cx="12" cy="13" r="4" /></IconBase>);
const ShirtIcon = ({ className }) => (<IconBase className={className}><path d="M9 4l3 2 3-2 4 3-2 4-2-1v10H9V10l-2 1-2-4 4-3z" /></IconBase>);
const SocialIcon = ({ className }) => (<IconBase className={className}><circle cx="6.5" cy="12" r="2.2" /><circle cx="17.5" cy="7" r="2.2" /><circle cx="17.5" cy="17" r="2.2" /><path d="M8.6 11l6.6-3" /><path d="M8.6 13l6.6 3" /></IconBase>);
const Wand2Icon = ({ className }) => (<IconBase className={className}><path d="M15 4V2" /><path d="M15 10V8" /><path d="M19 6h2" /><path d="M9 6H7" /><path d="M17.5 3.5l1-1" /><path d="M12 21l-7-7 9-9 7 7-9 9z" /></IconBase>);
const Layers3Icon = ({ className }) => (<IconBase className={className}><path d="M12 3l9 5-9 5-9-5 9-5z" /><path d="M3 12l9 5 9-5" /><path d="M3 16l9 5 9-5" /></IconBase>);
const CalendarDaysIcon = ({ className }) => (<IconBase className={className}><path d="M7 2v4" /><path d="M17 2v4" /><rect x="3" y="5" width="18" height="16" rx="2" /><path d="M3 10h18" /><path d="M8 14h.01" /><path d="M12 14h.01" /><path d="M16 14h.01" /></IconBase>);
const LockIcon = ({ className }) => (<IconBase className={className}><rect x="4" y="11" width="16" height="10" rx="2" /><path d="M8 11V8a4 4 0 1 1 8 0v3" /></IconBase>);
const SmartphoneIcon = ({ className }) => (<IconBase className={className}><rect x="7" y="2" width="10" height="20" rx="2" /><path d="M11 18h2" /></IconBase>);
const ScanLineIcon = ({ className }) => (<IconBase className={className}><path d="M4 7V5a1 1 0 0 1 1-1h2" /><path d="M17 4h2a1 1 0 0 1 1 1v2" /><path d="M20 17v2a1 1 0 0 1-1 1h-2" /><path d="M7 20H5a1 1 0 0 1-1-1v-2" /><path d="M4 12h16" /></IconBase>);
const CloudSunIcon = ({ className }) => (<IconBase className={className}><path d="M12 5V3" /><path d="M5.6 6.6L4.2 5.2" /><path d="M3 12H1" /><path d="M18 18a4 4 0 1 0-1.2-7.8A5 5 0 0 0 7 11a4 4 0 0 0 1 7h10z" /><circle cx="12" cy="12" r="3" /></IconBase>);
const ZapIcon = ({ className }) => (<IconBase className={className}><path d="M13 2L3 14h7l-1 8 10-12h-7l1-8z" /></IconBase>);
const ShoppingBagIcon = ({ className }) => (<IconBase className={className}><path d="M6 2 3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4z" /><line x1="3" y1="6" x2="21" y2="6" /><path d="M16 10a4 4 0 0 1-8 0" /></IconBase>);
const XIcon = ({ className }) => (<IconBase className={className}><path d="M18 6L6 18" /><path d="M6 6l12 12" /></IconBase>);
const ChevronDownIcon = ({ className }) => (<IconBase className={className}><path d="M6 9l6 6 6-6" /></IconBase>);
const ShieldIcon = ({ className }) => (<IconBase className={className}><path d="M12 2L4 6v6c0 5.25 3.5 10.15 8 11.35C16.5 22.15 20 17.25 20 12V6l-8-4z" /></IconBase>);
const FileTextIcon = ({ className }) => (<IconBase className={className}><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z" /><polyline points="14 2 14 8 20 8" /><line x1="16" y1="13" x2="8" y2="13" /><line x1="16" y1="17" x2="8" y2="17" /><polyline points="10 9 9 9 8 9" /></IconBase>);
const CookieIcon = ({ className }) => (<IconBase className={className}><circle cx="12" cy="12" r="10" /><path d="M8 13.5a.5.5 0 1 0 0-1 .5.5 0 0 0 0 1z" fill="currentColor" /><path d="M12 7.5a.5.5 0 1 0 0-1 .5.5 0 0 0 0 1z" fill="currentColor" /><path d="M16 13.5a.5.5 0 1 0 0-1 .5.5 0 0 0 0 1z" fill="currentColor" /><path d="M12 17.5a.5.5 0 1 0 0-1 .5.5 0 0 0 0 1z" fill="currentColor" /></IconBase>);

// ─── Cookie Consent ───────────────────────────────────────────────────────────
const COOKIE_KEY = "vroche_cookie_consent_v1";

function getCookieConsent() {
  try { return JSON.parse(localStorage.getItem(COOKIE_KEY)); } catch { return null; }
}
function setCookieConsent(value) {
  try { localStorage.setItem(COOKIE_KEY, JSON.stringify(value)); } catch {}
}

function CookieBanner({ onOpenPolicy }) {
  const [visible, setVisible] = useState(false);
  const [showDetails, setShowDetails] = useState(false);
  const [prefs, setPrefs] = useState({ analytics: false, marketing: false });

  useEffect(() => {
    const consent = getCookieConsent();
    if (!consent) setVisible(true);
  }, []);

  function acceptAll() {
    setCookieConsent({ analytics: true, marketing: true, necessary: true, ts: Date.now() });
    setVisible(false);
    // Here you would init Google Analytics, etc.
  }
  function rejectAll() {
    setCookieConsent({ analytics: false, marketing: false, necessary: true, ts: Date.now() });
    setVisible(false);
  }
  function savePrefs() {
    setCookieConsent({ ...prefs, necessary: true, ts: Date.now() });
    setVisible(false);
  }

  if (!visible) return null;

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-label="Consentimiento de cookies"
      style={{
        position: "fixed", bottom: 0, left: 0, right: 0, zIndex: 9999,
        padding: "0 0 env(safe-area-inset-bottom)",
        fontFamily: "DM Sans, sans-serif",
      }}
    >
      <div style={{
        background: "rgba(4,8,6,0.97)",
        backdropFilter: "blur(24px)",
        borderTop: "1px solid rgba(99,215,177,0.18)",
        padding: "20px 24px",
        maxWidth: "100%",
      }}>
        <div style={{ maxWidth: 960, margin: "0 auto" }}>
          {/* Header */}
          <div style={{ display: "flex", alignItems: "flex-start", gap: 12, marginBottom: 12 }}>
            <CookieIcon className="h-5 w-5" style={{ color: BRAND.mint, flexShrink: 0, marginTop: 2 }} />
            <div style={{ flex: 1 }}>
              <p style={{ color: "#FCFFFE", fontSize: 14, fontWeight: 700, margin: 0 }}>
                Vroche usa cookies
              </p>
              <p style={{ color: "rgba(252,255,254,0.62)", fontSize: 13, margin: "4px 0 0", lineHeight: 1.6 }}>
                Usamos cookies necesarias para el funcionamiento de la web y, con tu consentimiento, cookies analíticas (Google Analytics) para mejorar nuestra experiencia.{" "}
                <button onClick={onOpenPolicy} style={{ color: BRAND.mint, background: "none", border: "none", cursor: "pointer", fontSize: 13, padding: 0, textDecoration: "underline" }}>
                  Política de cookies
                </button>
              </p>
            </div>
          </div>

          {/* Expandable details */}
          {showDetails && (
            <div style={{
              background: "rgba(255,255,255,0.04)",
              borderRadius: 14,
              padding: "14px 16px",
              marginBottom: 14,
              display: "flex", flexDirection: "column", gap: 10,
            }}>
              <CookieToggle
                title="Cookies necesarias"
                desc="Imprescindibles para el funcionamiento de la web. No se pueden desactivar."
                checked={true}
                disabled={true}
              />
              <CookieToggle
                title="Cookies analíticas (Google Analytics)"
                desc="Nos permiten entender cómo usas la web. Los datos son anónimos."
                checked={prefs.analytics}
                onChange={v => setPrefs(p => ({ ...p, analytics: v }))}
              />
              <CookieToggle
                title="Cookies de marketing"
                desc="Para mostrarte anuncios relevantes. Actualmente no activas."
                checked={prefs.marketing}
                onChange={v => setPrefs(p => ({ ...p, marketing: v }))}
              />
            </div>
          )}

          {/* Actions */}
          <div style={{ display: "flex", flexWrap: "wrap", gap: 8, alignItems: "center" }}>
            <button
              onClick={() => setShowDetails(d => !d)}
              style={{
                background: "rgba(255,255,255,0.07)", border: "1px solid rgba(255,255,255,0.12)",
                color: "rgba(252,255,254,0.7)", borderRadius: 999, padding: "9px 16px",
                fontSize: 12, fontWeight: 600, cursor: "pointer", display: "flex", alignItems: "center", gap: 5,
                fontFamily: "DM Sans, sans-serif",
              }}
            >
              {showDetails ? "Ocultar opciones" : "Personalizar"}
              <ChevronDownIcon className="h-3 w-3" style={{ transform: showDetails ? "rotate(180deg)" : "none", transition: "transform 0.2s" }} />
            </button>
            {showDetails && (
              <button onClick={savePrefs} style={{
                background: "rgba(255,255,255,0.1)", border: "1px solid rgba(255,255,255,0.18)",
                color: "#FCFFFE", borderRadius: 999, padding: "9px 18px",
                fontSize: 12, fontWeight: 700, cursor: "pointer", fontFamily: "DM Sans, sans-serif",
              }}>
                Guardar preferencias
              </button>
            )}
            <div style={{ marginLeft: "auto", display: "flex", gap: 8, flexWrap: "wrap" }}>
              <button onClick={rejectAll} style={{
                background: "transparent", border: "1px solid rgba(255,255,255,0.18)",
                color: "rgba(252,255,254,0.65)", borderRadius: 999, padding: "9px 18px",
                fontSize: 12, fontWeight: 600, cursor: "pointer", fontFamily: "DM Sans, sans-serif",
              }}>
                Solo necesarias
              </button>
              <button onClick={acceptAll} style={{
                background: BRAND.mint, border: "none",
                color: BRAND.black, borderRadius: 999, padding: "9px 20px",
                fontSize: 12, fontWeight: 800, cursor: "pointer", letterSpacing: "0.08em",
                fontFamily: "DM Sans, sans-serif",
              }}>
                Aceptar todo
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function CookieToggle({ title, desc, checked, disabled, onChange }) {
  return (
    <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", gap: 12 }}>
      <div>
        <p style={{ color: "#FCFFFE", fontSize: 13, fontWeight: 600, margin: 0 }}>{title}</p>
        <p style={{ color: "rgba(252,255,254,0.48)", fontSize: 12, margin: "2px 0 0", lineHeight: 1.5 }}>{desc}</p>
      </div>
      <label style={{ flexShrink: 0, position: "relative", cursor: disabled ? "not-allowed" : "pointer" }}>
        <input
          type="checkbox"
          checked={checked}
          disabled={disabled}
          onChange={e => onChange && onChange(e.target.checked)}
          style={{ position: "absolute", opacity: 0, width: 0, height: 0 }}
        />
        <div style={{
          width: 40, height: 22, borderRadius: 999,
          background: checked ? BRAND.mint : "rgba(255,255,255,0.15)",
          transition: "background 0.2s",
          display: "flex", alignItems: "center",
          padding: "2px",
          opacity: disabled ? 0.5 : 1,
        }}>
          <div style={{
            width: 18, height: 18, borderRadius: "50%",
            background: "#FCFFFE",
            transform: checked ? "translateX(18px)" : "translateX(0)",
            transition: "transform 0.2s",
          }} />
        </div>
      </label>
    </div>
  );
}

// ─── Legal Modal ──────────────────────────────────────────────────────────────
function LegalModal({ page, onClose }) {
  useEffect(() => {
    document.body.style.overflow = "hidden";
    const handler = (e) => { if (e.key === "Escape") onClose(); };
    window.addEventListener("keydown", handler);
    return () => { document.body.style.overflow = ""; window.removeEventListener("keydown", handler); };
  }, [onClose]);

  const pages = {
    privacy: <PrivacyPolicy />,
    terms: <TermsConditions />,
    legal: <LegalNotice />,
    cookies: <CookiePolicy />,
  };

  const titles = {
    privacy: "Política de Privacidad",
    terms: "Términos y Condiciones",
    legal: "Aviso Legal",
    cookies: "Política de Cookies",
  };

  return (
    <div
      onClick={e => { if (e.target === e.currentTarget) onClose(); }}
      style={{
        position: "fixed", inset: 0, zIndex: 10000,
        background: "rgba(4,8,6,0.88)",
        backdropFilter: "blur(16px)",
        display: "flex", alignItems: "flex-end", justifyContent: "center",
        fontFamily: "DM Sans, sans-serif",
      }}
      role="dialog" aria-modal="true" aria-label={titles[page]}
    >
      <div style={{
        background: "#0a120e",
        border: "1px solid rgba(99,215,177,0.14)",
        borderRadius: "28px 28px 0 0",
        width: "100%", maxWidth: 780,
        maxHeight: "90vh",
        display: "flex", flexDirection: "column",
        overflow: "hidden",
      }}>
        {/* Sticky header */}
        <div style={{
          padding: "20px 28px 16px",
          borderBottom: "1px solid rgba(255,255,255,0.07)",
          display: "flex", alignItems: "center", justifyContent: "space-between",
          flexShrink: 0,
        }}>
          <h2 style={{ color: "#FCFFFE", fontSize: 18, fontWeight: 800, margin: 0, letterSpacing: "-0.02em" }}>
            {titles[page]}
          </h2>
          <button
            onClick={onClose}
            aria-label="Cerrar"
            style={{
              background: "rgba(255,255,255,0.07)", border: "1px solid rgba(255,255,255,0.1)",
              borderRadius: "50%", width: 36, height: 36,
              display: "flex", alignItems: "center", justifyContent: "center",
              cursor: "pointer", color: "rgba(252,255,254,0.7)",
            }}
          >
            <XIcon className="h-4 w-4" />
          </button>
        </div>
        {/* Scrollable content */}
        <div style={{ overflowY: "auto", padding: "24px 28px 40px", flex: 1 }}>
          {pages[page]}
        </div>
      </div>
    </div>
  );
}

// ─── Legal Content Components ─────────────────────────────────────────────────
const legalStyles = {
  h2: { color: BRAND.mint, fontSize: 15, fontWeight: 800, marginTop: 28, marginBottom: 8, letterSpacing: "-0.01em" },
  h3: { color: "#FCFFFE", fontSize: 13, fontWeight: 700, marginTop: 18, marginBottom: 6 },
  p: { color: "rgba(252,255,254,0.68)", fontSize: 13, lineHeight: 1.75, margin: "0 0 10px" },
  li: { color: "rgba(252,255,254,0.68)", fontSize: 13, lineHeight: 1.75, marginBottom: 4 },
  date: { color: "rgba(252,255,254,0.38)", fontSize: 12, marginBottom: 20, display: "block" },
  link: { color: BRAND.mint, textDecoration: "none" },
  table: { width: "100%", borderCollapse: "collapse", marginBottom: 16, fontSize: 12 },
  th: { color: BRAND.mint, fontWeight: 700, padding: "8px 10px", borderBottom: "1px solid rgba(99,215,177,0.2)", textAlign: "left" },
  td: { color: "rgba(252,255,254,0.65)", padding: "8px 10px", borderBottom: "1px solid rgba(255,255,255,0.06)", verticalAlign: "top" },
};

function LegalSection({ title, children }) {
  return (
    <>
      <h2 style={legalStyles.h2}>{title}</h2>
      {children}
    </>
  );
}

function PrivacyPolicy() {
  return (
    <div>
      <span style={legalStyles.date}>Última actualización: mayo de 2025 · Versión 1.0</span>
      <p style={legalStyles.p}>
        En <strong style={{ color: "#FCFFFE" }}>VROCHE APP S.L.</strong> (en adelante, «Vroche») tratamos tus datos personales con total transparencia y en cumplimiento del <strong style={{ color: "#FCFFFE" }}>Reglamento (UE) 2016/679 (RGPD)</strong> y la <strong style={{ color: "#FCFFFE" }}>Ley Orgánica 3/2018, de 5 de diciembre, de Protección de Datos Personales y garantía de los derechos digitales (LOPDGDD)</strong>.
      </p>

      <LegalSection title="1. Responsable del tratamiento">
        <table style={legalStyles.table}>
          <tbody>
            {[
              ["Denominación social", LEGAL.company],
              ["CIF", LEGAL.cif],
              ["Domicilio social", LEGAL.address],
              ["Correo de contacto", LEGAL.email],
              ["DPO / Delegado de protección", LEGAL.dpo_email],
            ].map(([k, v]) => (
              <tr key={k}>
                <td style={{ ...legalStyles.td, fontWeight: 600, color: "rgba(252,255,254,0.85)", width: "42%" }}>{k}</td>
                <td style={legalStyles.td}>{v}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </LegalSection>

      <LegalSection title="2. Datos que recogemos y finalidades">
        <table style={legalStyles.table}>
          <thead>
            <tr>
              <th style={legalStyles.th}>Dato</th>
              <th style={legalStyles.th}>Finalidad</th>
              <th style={legalStyles.th}>Base legal</th>
            </tr>
          </thead>
          <tbody>
            {[
              ["Nombre y correo electrónico", "Gestión de acceso beta / waitlist y comunicaciones sobre el servicio", "Consentimiento (art. 6.1.a RGPD)"],
              ["Número de teléfono", "Comunicación directa y soporte durante la beta", "Consentimiento (art. 6.1.a RGPD)"],
              ["Fotografías / imágenes", "Funcionalidad de virtual try-on (prueba de prendas sobre tu imagen)", "Consentimiento explícito (art. 9 RGPD, datos biométricos)"],
              ["Medidas corporales y talla", "Recomendaciones de estilo personalizadas", "Consentimiento (art. 6.1.a RGPD)"],
              ["Perfil de estilo y preferencias", "Personalización de la experiencia AI Stylist", "Consentimiento (art. 6.1.a RGPD)"],
              ["Login social (Google, Apple)", "Autenticación en la aplicación", "Ejecución de contrato (art. 6.1.b RGPD)"],
              ["Datos de navegación / cookies", "Análisis estadístico del uso de la web (Google Analytics)", "Consentimiento (art. 6.1.a RGPD)"],
            ].map(([dato, fin, base]) => (
              <tr key={dato}>
                <td style={{ ...legalStyles.td, fontWeight: 600, color: "rgba(252,255,254,0.85)" }}>{dato}</td>
                <td style={legalStyles.td}>{fin}</td>
                <td style={legalStyles.td}>{base}</td>
              </tr>
            ))}
          </tbody>
        </table>
        <p style={{ ...legalStyles.p, borderLeft: `3px solid ${BRAND.coral}`, paddingLeft: 12 }}>
          <strong style={{ color: "#FCFFFE" }}>Nota especial sobre imágenes:</strong> Las fotografías con imágenes de personas pueden constituir datos biométricos (categoría especial, art. 9 RGPD). Tratamos estas imágenes exclusivamente para la funcionalidad de virtual try-on y las eliminamos de nuestros servidores en el plazo máximo de 30 días desde su carga, salvo que el usuario solicite su eliminación antes.
        </p>
        <p style={{ ...legalStyles.p, borderLeft: `3px solid ${BRAND.coral}`, paddingLeft: 12 }}>
          <strong style={{ color: "#FCFFFE" }}>Menores de 14 años:</strong> Conforme al art. 7 LOPDGDD, los menores de 14 años requieren consentimiento parental para registrarse. Si detectamos que un usuario menor de 14 años se ha registrado sin dicho consentimiento, eliminaremos su cuenta de inmediato.
        </p>
      </LegalSection>

      <LegalSection title="3. Conservación de los datos">
        <p style={legalStyles.p}>Conservamos tus datos mientras mantengas tu cuenta activa o mientras sean necesarios para prestarte el servicio. Transcurrido ese período, los bloqueamos durante los plazos legales de prescripción (máximo 6 años, art. 30 Código de Comercio) y posteriormente los eliminamos de forma segura.</p>
      </LegalSection>

      <LegalSection title="4. Destinatarios y transferencias internacionales">
        <p style={legalStyles.p}>Podemos compartir tus datos con los siguientes proveedores (encargados del tratamiento), todos con garantías adecuadas:</p>
        <ul style={{ paddingLeft: 20 }}>
          {[
            "Google LLC (Analytics, Firebase, Google Sign-In) — transferencia amparada en Cláusulas Contractuales Tipo",
            "Apple Inc. (Sign in with Apple) — transferencia amparada en Cláusulas Contractuales Tipo",
            "Proveedores de infraestructura cloud en la UE/EEE",
          ].map(item => <li key={item} style={legalStyles.li}>{item}</li>)}
        </ul>
        <p style={legalStyles.p}>No vendemos ni cedemos datos a terceros para sus propias finalidades comerciales.</p>
      </LegalSection>

      <LegalSection title="5. Tus derechos (RGPD)">
        <p style={legalStyles.p}>Puedes ejercer en cualquier momento los siguientes derechos enviando un correo a <a href={`mailto:${LEGAL.email}`} style={legalStyles.link}>{LEGAL.email}</a> con copia de tu DNI u otro documento identificativo:</p>
        <ul style={{ paddingLeft: 20 }}>
          {[
            "Acceso: conocer qué datos tenemos sobre ti.",
            "Rectificación: corregir datos inexactos o incompletos.",
            "Supresión (derecho al olvido): solicitar la eliminación de tus datos.",
            "Oposición: oponerte al tratamiento basado en interés legítimo.",
            "Limitación: solicitar la restricción del tratamiento.",
            "Portabilidad: recibir tus datos en formato estructurado.",
            "Retirada del consentimiento: sin que ello afecte al tratamiento previo.",
            "No ser objeto de decisiones automatizadas con efectos significativos.",
          ].map(item => <li key={item} style={legalStyles.li}>{item}</li>)}
        </ul>
        <p style={legalStyles.p}>Si no obtienes respuesta satisfactoria en el plazo de 1 mes, puedes presentar una reclamación ante la <strong style={{ color: "#FCFFFE" }}>Agencia Española de Protección de Datos (AEPD)</strong>: <a href={LEGAL.aepd_url} style={legalStyles.link} target="_blank" rel="noopener noreferrer">www.aepd.es</a>.</p>
      </LegalSection>

      <LegalSection title="6. Seguridad">
        <p style={legalStyles.p}>Aplicamos medidas técnicas y organizativas apropiadas (cifrado TLS, control de acceso, seudonimización) para proteger tus datos frente a accesos no autorizados, pérdida o destrucción. En caso de brecha de seguridad con riesgo para tus derechos, te notificaremos en el plazo máximo de 72 horas establecido por el RGPD.</p>
      </LegalSection>

      <LegalSection title="7. Cambios en esta política">
        <p style={legalStyles.p}>Si realizamos cambios materiales, te lo notificaremos por correo electrónico o mediante un aviso destacado en la app con al menos 15 días de antelación.</p>
      </LegalSection>
    </div>
  );
}

function TermsConditions() {
  return (
    <div>
      <span style={legalStyles.date}>Última actualización: mayo de 2025 · Versión 1.0</span>
      <p style={legalStyles.p}>Estos Términos y Condiciones regulan el acceso y uso de la plataforma <strong style={{ color: "#FCFFFE" }}>Vroche</strong> (web y aplicación móvil) ofrecida por <strong style={{ color: "#FCFFFE" }}>VROCHE APP S.L.</strong> (en adelante, «Vroche» o «nosotros»).</p>

      <LegalSection title="1. Aceptación">
        <p style={legalStyles.p}>El acceso a Vroche implica la aceptación plena y sin reservas de estos Términos. Si no estás de acuerdo, no debes utilizar el servicio.</p>
      </LegalSection>

      <LegalSection title="2. Descripción del servicio y fase beta">
        <p style={legalStyles.p}>Vroche es una aplicación de moda con inteligencia artificial que ofrece, entre otras funciones, virtual try-on, armario digital, recomendaciones de estilo personalizadas y una red social de moda.</p>
        <p style={{ ...legalStyles.p, borderLeft: `3px solid ${BRAND.mint}`, paddingLeft: 12 }}>
          <strong style={{ color: "#FCFFFE" }}>El servicio se encuentra actualmente en fase de beta cerrada.</strong> Esto implica que puede contener errores, funcionalidades incompletas y que Vroche puede interrumpir, modificar o discontinuar el acceso en cualquier momento sin previo aviso. El acceso beta se otorga de forma gratuita y sin garantías de continuidad.
        </p>
      </LegalSection>

      <LegalSection title="3. Registro y cuenta">
        <ul style={{ paddingLeft: 20 }}>
          <li style={legalStyles.li}>Debes tener al menos <strong style={{ color: "#FCFFFE" }}>14 años</strong> para registrarte. Los menores de 14 años necesitan consentimiento parental verificable.</li>
          <li style={legalStyles.li}>Eres responsable de mantener la confidencialidad de tus credenciales.</li>
          <li style={legalStyles.li}>Debes proporcionar información veraz y actualizada.</li>
          <li style={legalStyles.li}>Está prohibido crear cuentas con identidades falsas o suplantar a otras personas.</li>
        </ul>
      </LegalSection>

      <LegalSection title="4. Uso aceptable">
        <p style={legalStyles.p}>Queda expresamente prohibido:</p>
        <ul style={{ paddingLeft: 20 }}>
          {[
            "Subir contenido ilegal, ofensivo, discriminatorio, pornográfico o que infrinja derechos de terceros.",
            "Utilizar la plataforma para spam, phishing o cualquier actividad fraudulenta.",
            "Intentar acceder de forma no autorizada a sistemas o cuentas de otros usuarios.",
            "Realizar ingeniería inversa, descompilar o intentar extraer el código fuente de la app.",
            "Usar bots o herramientas automatizadas para acceder al servicio sin autorización expresa.",
            "Subir imágenes de terceros sin su consentimiento expreso.",
          ].map(item => <li key={item} style={legalStyles.li}>{item}</li>)}
        </ul>
      </LegalSection>

      <LegalSection title="5. Contenido generado por el usuario">
        <p style={legalStyles.p}>Al subir contenido (fotos, looks, comentarios), conservas la titularidad de tus derechos de propiedad intelectual, pero concedes a Vroche una licencia mundial, no exclusiva, gratuita y transferible para usar, mostrar, almacenar y procesar dicho contenido exclusivamente con la finalidad de prestar el servicio.</p>
        <p style={legalStyles.p}>Vroche puede eliminar cualquier contenido que infrinja estos Términos o la legislación aplicable, sin necesidad de previo aviso.</p>
      </LegalSection>

      <LegalSection title="6. Propiedad intelectual de Vroche">
        <p style={legalStyles.p}>Todos los elementos de la plataforma (diseño, código, marca, logotipos, textos, modelos de IA) son propiedad de VROCHE APP S.L. o de sus licenciantes y están protegidos por la legislación española e internacional de propiedad intelectual e industrial. Queda prohibida su reproducción, distribución o comunicación pública sin autorización expresa.</p>
      </LegalSection>

      <LegalSection title="7. Exclusión de garantías y limitación de responsabilidad">
        <p style={legalStyles.p}>El servicio se presta «tal cual» (as-is) durante la fase beta. Vroche no garantiza la disponibilidad ininterrumpida, la exactitud de las recomendaciones de estilo ni la calidad de los resultados de virtual try-on. En ningún caso la responsabilidad de Vroche superará el importe que el usuario haya abonado en los 12 meses anteriores al hecho causante (que durante la beta será de cero euros).</p>
      </LegalSection>

      <LegalSection title="8. Suspensión y cancelación">
        <p style={legalStyles.p}>Vroche puede suspender o cancelar tu cuenta si incumples estos Términos. Puedes cancelar tu cuenta en cualquier momento enviando un correo a <a href={`mailto:${LEGAL.email}`} style={legalStyles.link}>{LEGAL.email}</a>.</p>
      </LegalSection>

      <LegalSection title="9. Modificaciones">
        <p style={legalStyles.p}>Vroche puede modificar estos Términos. En caso de cambios materiales, te notificaremos con al menos 15 días de antelación. El uso continuado del servicio tras esa fecha implica la aceptación de los nuevos Términos.</p>
      </LegalSection>

      <LegalSection title="10. Ley aplicable y jurisdicción">
        <p style={legalStyles.p}>Estos Términos se rigen por la legislación española. Para la resolución de disputas, las partes se someten a los Juzgados y Tribunales de Madrid, salvo que la normativa de consumidores y usuarios aplicable establezca un fuero diferente.</p>
        <p style={legalStyles.p}>Para resolución extrajudicial de conflictos en línea (ODR), la Comisión Europea pone a disposición la siguiente plataforma: <a href="https://ec.europa.eu/consumers/odr" target="_blank" rel="noopener noreferrer" style={legalStyles.link}>https://ec.europa.eu/consumers/odr</a>.</p>
      </LegalSection>
    </div>
  );
}

function LegalNotice() {
  return (
    <div>
      <span style={legalStyles.date}>Última actualización: mayo de 2025</span>
      <p style={legalStyles.p}>En cumplimiento del artículo 10 de la <strong style={{ color: "#FCFFFE" }}>Ley 34/2002, de 11 de julio, de Servicios de la Sociedad de la Información y de Comercio Electrónico (LSSI-CE)</strong>, se facilitan los siguientes datos identificativos:</p>

      <table style={legalStyles.table}>
        <tbody>
          {[
            ["Denominación social", LEGAL.company],
            ["CIF", LEGAL.cif],
            ["Domicilio social", LEGAL.address + ", España"],
            ["Correo electrónico", LEGAL.email],
            ["Dominio web", LEGAL.domain],
            ["Inscripción registral", "Pendiente de inscripción en el Registro Mercantil de Madrid"],
          ].map(([k, v]) => (
            <tr key={k}>
              <td style={{ ...legalStyles.td, fontWeight: 600, color: "rgba(252,255,254,0.85)", width: "42%" }}>{k}</td>
              <td style={legalStyles.td}>{v}</td>
            </tr>
          ))}
        </tbody>
      </table>

      <LegalSection title="Objeto y actividad">
        <p style={legalStyles.p}>VROCHE APP S.L. es titular del sitio web <strong style={{ color: "#FCFFFE" }}>vroche.com</strong> y de la aplicación móvil Vroche, dedicados a ofrecer servicios de moda inteligente basados en inteligencia artificial.</p>
      </LegalSection>

      <LegalSection title="Propiedad intelectual e industrial">
        <p style={legalStyles.p}>Todos los contenidos del sitio web (textos, imágenes, diseños gráficos, código fuente, logotipos y marcas) son propiedad de VROCHE APP S.L. o de sus licenciantes, y están protegidos por las leyes españolas e internacionales de propiedad intelectual e industrial. Se prohíbe expresamente su reproducción, distribución, comunicación pública o transformación sin autorización previa y por escrito de VROCHE APP S.L.</p>
      </LegalSection>

      <LegalSection title="Exclusión de responsabilidad">
        <p style={legalStyles.p}>VROCHE APP S.L. no se hace responsable de los daños o perjuicios de cualquier naturaleza causados por la imposibilidad de acceder al servicio, por interrupciones, virus informáticos o fallos en la conexión, ni por el uso inadecuado que el usuario pudiera realizar de los contenidos del sitio.</p>
      </LegalSection>

      <LegalSection title="Legislación aplicable">
        <p style={legalStyles.p}>El presente aviso legal se rige en su totalidad por la legislación española, siendo competentes los Juzgados y Tribunales de Madrid para conocer de cuantas cuestiones se susciten sobre la interpretación, aplicación y cumplimiento del mismo.</p>
      </LegalSection>
    </div>
  );
}

function CookiePolicy() {
  return (
    <div>
      <span style={legalStyles.date}>Última actualización: mayo de 2025</span>
      <p style={legalStyles.p}>Esta Política de Cookies explica qué son las cookies, qué tipos utilizamos en <strong style={{ color: "#FCFFFE" }}>vroche.com</strong> y cómo puedes gestionarlas, en cumplimiento del artículo 22.2 de la LSSI-CE y el RGPD.</p>

      <LegalSection title="¿Qué es una cookie?">
        <p style={legalStyles.p}>Una cookie es un fichero de texto que un sitio web envía al navegador y que queda almacenado en tu dispositivo. Las cookies permiten al sitio recordar tus preferencias y analizar cómo utilizas la página.</p>
      </LegalSection>

      <LegalSection title="Tipos de cookies que utilizamos">
        <table style={legalStyles.table}>
          <thead>
            <tr>
              <th style={legalStyles.th}>Cookie</th>
              <th style={legalStyles.th}>Tipo</th>
              <th style={legalStyles.th}>Finalidad</th>
              <th style={legalStyles.th}>Duración</th>
              <th style={legalStyles.th}>Consentimiento</th>
            </tr>
          </thead>
          <tbody>
            {[
              ["vroche_cookie_consent_v1", "Técnica / Necesaria", "Almacena tus preferencias de consentimiento", "1 año", "No requerido"],
              ["_ga, _ga_*", "Analítica (Google Analytics 4)", "Análisis estadístico del uso de la web (datos anónimos)", "2 años / sesión", "Requerido"],
              ["_gid", "Analítica (Google Analytics)", "Distingue sesiones de usuario (datos anónimos)", "24 horas", "Requerido"],
            ].map(([name, tipo, fin, dur, cons]) => (
              <tr key={name}>
                <td style={{ ...legalStyles.td, fontFamily: "monospace", fontSize: 11, color: BRAND.mint }}>{name}</td>
                <td style={legalStyles.td}>{tipo}</td>
                <td style={legalStyles.td}>{fin}</td>
                <td style={legalStyles.td}>{dur}</td>
                <td style={{ ...legalStyles.td, color: cons === "No requerido" ? "rgba(252,255,254,0.45)" : BRAND.mint }}>{cons}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </LegalSection>

      <LegalSection title="Cookies de Google Analytics">
        <p style={legalStyles.p}>Utilizamos Google Analytics 4 de Google LLC para analizar el uso de nuestra web. Google puede transferir esta información a terceros cuando así lo requiera la legislación o cuando dichos terceros procesen la información en nombre de Google. Hemos activado la <strong style={{ color: "#FCFFFE" }}>anonimización de IP</strong> y hemos suscrito el Acuerdo de Procesamiento de Datos con Google. Más información en la <a href="https://policies.google.com/privacy" target="_blank" rel="noopener noreferrer" style={legalStyles.link}>Política de Privacidad de Google</a>.</p>
      </LegalSection>

      <LegalSection title="Gestión y retirada del consentimiento">
        <p style={legalStyles.p}>Puedes gestionar tus preferencias de cookies en cualquier momento a través del panel de preferencias (disponible en el pie de página de la web). También puedes desactivar las cookies desde la configuración de tu navegador:</p>
        <ul style={{ paddingLeft: 20 }}>
          {[
            ["Chrome", "chrome://settings/cookies"],
            ["Firefox", "about:preferences#privacy"],
            ["Safari", "Preferencias > Privacidad"],
            ["Edge", "edge://settings/cookies"],
          ].map(([nav, url]) => (
            <li key={nav} style={legalStyles.li}>
              <strong style={{ color: "#FCFFFE" }}>{nav}:</strong>{" "}
              {url.startsWith("http") ? <a href={url} target="_blank" rel="noopener noreferrer" style={legalStyles.link}>{url}</a> : <span style={{ fontFamily: "monospace", color: "rgba(252,255,254,0.75)" }}>{url}</span>}
            </li>
          ))}
        </ul>
        <p style={legalStyles.p}>Ten en cuenta que deshabilitar ciertas cookies puede afectar al funcionamiento de la web.</p>
      </LegalSection>
    </div>
  );
}

// ─── Existing Components (unchanged) ─────────────────────────────────────────
function Badge({ children, className = "" }) {
  return (
    <div className={`inline-flex items-center gap-2 rounded-full border border-white/10 bg-white/[0.06] px-4 py-2 text-xs font-extrabold uppercase tracking-[0.2em] text-white backdrop-blur-xl ${className}`} style={{ fontFamily: "DM Sans" }}>
      {children}
    </div>
  );
}
function SectionLabel({ children }) {
  return <p className="font-subtitle mb-5 text-xs font-extrabold uppercase tracking-[0.3em] text-black/40">{children}</p>;
}
function Pill({ children }) {
  return <span className="rounded-full border border-black/10 bg-black/[0.04] px-4 py-2 text-sm font-medium text-black/70" style={{ fontFamily: "Roboto" }}>{children}</span>;
}
function FeatureCard({ icon: Icon, title, text, accent }) {
  const isAccent = accent === "coral";
  return (
    <div className={`mobile-card group relative overflow-hidden rounded-[2rem] border p-7 transition hover:scale-[1.02] ${isAccent ? "border-[#FF5733]/20 bg-[#FF5733]/[0.04]" : "border-black/[0.08] bg-white shadow-[0_20px_70px_rgba(4,8,6,0.06)]"}`}>
      <div className={`mobile-icon-box mb-6 flex h-12 w-12 items-center justify-center rounded-2xl ${isAccent ? "bg-[#FF5733]/15" : "bg-[#63D7B1]/15"}`}>
        <Icon className={`h-5 w-5 ${isAccent ? "text-[#FF5733]" : "text-[#040806]"}`} />
      </div>
      <h3 className="mobile-card-title font-subtitle mb-3 text-xl font-extrabold tracking-[-0.02em]">{title}</h3>
      <p className="mobile-card-text font-body text-sm leading-7 text-black/[0.55]">{text}</p>
    </div>
  );
}
function NavChipGroup() {
  return (
    <nav aria-label="Secciones" className="hidden items-center gap-1 md:flex">
      {[["#product", "Producto"], ["#how", "Cómo funciona"], ["#vision", "Visión"], ["#waitlist", "Beta"]].map(([href, label]) => (
        <a key={href} href={href} className="rounded-full px-4 py-2 text-xs font-semibold text-white/60 transition hover:bg-white/[0.08] hover:text-white" style={{ fontFamily: "DM Sans" }}>{label}</a>
      ))}
    </nav>
  );
}
function HeaderLogo() {
  return (
    <div className="mobile-header-logo flex items-center">
      <img src={VROCHE_LOGO_TEXT_SRC} alt="Vroche" className="mobile-header-logo-img" style={{ height: 34, width: "auto", maxWidth: 145, objectFit: "contain" }} />
    </div>
  );
}
function LogoRevealBackground() {
  const fieldRef = useRef(null);
  const rafRef = useRef(null);
  const pointerRef = useRef({ x: -9999, y: -9999 });
  const handlePointerMove = useCallback((e) => {
    pointerRef.current = { x: e.clientX, y: e.clientY };
    if (rafRef.current) return;
    rafRef.current = requestAnimationFrame(() => {
      rafRef.current = null;
      if (!fieldRef.current) return;
      const { x, y } = pointerRef.current;
      fieldRef.current.style.setProperty("--reveal-x", `${x}px`);
      fieldRef.current.style.setProperty("--reveal-y", `${y}px`);
      fieldRef.current.style.setProperty("--reveal-opacity", "1");
    });
  }, []);
  const handlePointerLeave = useCallback(() => {
    if (fieldRef.current) {
      fieldRef.current.style.setProperty("--reveal-x", "-9999px");
      fieldRef.current.style.setProperty("--reveal-y", "-9999px");
      fieldRef.current.style.setProperty("--reveal-opacity", "0");
    }
  }, []);
  useEffect(() => {
    window.addEventListener("pointermove", handlePointerMove, { passive: true });
    window.addEventListener("pointerleave", handlePointerLeave, { passive: true });
    return () => {
      window.removeEventListener("pointermove", handlePointerMove);
      window.removeEventListener("pointerleave", handlePointerLeave);
      if (rafRef.current) cancelAnimationFrame(rafRef.current);
    };
  }, [handlePointerMove, handlePointerLeave]);
  return (
    <div ref={fieldRef} className="logo-reveal-field pointer-events-none fixed inset-0 z-0 overflow-hidden" aria-hidden="true">
      <div className="logo-noise-layer">
        {SCATTERED_LOGOS.map((item) => (
          <div key={item.id} className="logo-noise-wrap" style={{ position: "absolute", left: `${item.left}%`, top: `${item.top}%`, width: item.size + "px", height: item.size + "px", opacity: item.opacity, "--rotation": `${item.rotate}deg`, "--drift-x": `${item.driftX}px`, "--drift-y": `${item.driftY}px`, "--drift-duration": `${item.duration}s`, "--drift-delay": `${item.delay}s`, transform: `translate(-50%, -50%) rotate(${item.rotate}deg)` }}>
            <img src={VROCHE_LOGO_SRC} alt="" className="logo-noise-img logo-noise-img-base" style={{ width: item.size, height: item.size }} />
          </div>
        ))}
      </div>
      <div className="logo-reveal-layer">
        {SCATTERED_LOGOS.map((item) => (
          <div key={item.id + "-reveal"} className="logo-noise-wrap" style={{ position: "absolute", left: `${item.left}%`, top: `${item.top}%`, width: item.size + "px", height: item.size + "px", opacity: item.opacity * 2.5, "--rotation": `${item.rotate}deg`, "--drift-x": `${item.driftX}px`, "--drift-y": `${item.driftY}px`, "--drift-duration": `${item.duration}s`, "--drift-delay": `${item.delay}s`, transform: `translate(-50%, -50%) rotate(${item.rotate}deg)` }}>
            <img src={VROCHE_LOGO_SRC} alt="" className="logo-noise-img logo-noise-img-reveal" style={{ width: item.size, height: item.size }} />
          </div>
        ))}
      </div>
    </div>
  );
}
function Global3DVrocheLogo() {
  const rootRef = useRef(null);
  const objectRef = useRef(null);
  const rafRef = useRef(null);
  const pointerRef = useRef({ x: window.innerWidth / 2, y: window.innerHeight / 2 });
  useEffect(() => {
    function onPointerMove(e) {
      pointerRef.current = { x: e.clientX, y: e.clientY };
      if (rafRef.current) return;
      rafRef.current = requestAnimationFrame(() => {
        rafRef.current = null;
        if (!rootRef.current || !objectRef.current) return;
        const rect = objectRef.current.getBoundingClientRect();
        const { rotateX, rotateY, shineX, shineY } = calculateLogoRotation(pointerRef.current.x, pointerRef.current.y, rect, window.innerWidth, window.innerHeight);
        objectRef.current.style.transform = `rotateX(${rotateX}deg) rotateY(${rotateY}deg)`;
        rootRef.current.style.setProperty("--shine-x", `${shineX}%`);
        rootRef.current.style.setProperty("--shine-y", `${shineY}%`);
        rootRef.current.style.setProperty("--glow-x", `${shineX}%`);
        rootRef.current.style.setProperty("--glow-y", `${shineY}%`);
        rootRef.current.style.setProperty("--glow-opacity", "0.85");
      });
    }
    window.addEventListener("pointermove", onPointerMove, { passive: true });
    return () => { window.removeEventListener("pointermove", onPointerMove); if (rafRef.current) cancelAnimationFrame(rafRef.current); };
  }, []);
  const depths = [0.88, 0.76, 0.64, 0.52, 0.40, 0.28];
  return (
    <div ref={rootRef} className="logo3d-root relative mx-auto flex items-center justify-center" style={{ width: "min(420px, 76vw)", height: "min(420px, 76vw)" }} aria-hidden="true">
      <div className="logo3d-global-aura" />
      <div className="logo3d-orbit logo3d-orbit-a" />
      <div className="logo3d-orbit logo3d-orbit-b" />
      <div className="particle-a logo3d-particle" /><div className="particle-b logo3d-particle" /><div className="particle-c logo3d-particle" /><div className="particle-d logo3d-particle" />
      <div ref={objectRef} className="logo3d-object" style={{ animation: "heroFloat 6s ease-in-out infinite" }}>
        <div className="logo3d-depth-stack">
          {depths.map((op, i) => (
            <div key={i} style={{ position: "absolute", inset: 0, transform: `translateZ(${(i + 1) * -10}px)`, display: "flex", alignItems: "center", justifyContent: "center" }}>
              <img src={VROCHE_LOGO_SRC} alt="" className="logo-depth-image" style={{ opacity: op * 0.45 }} />
            </div>
          ))}
        </div>
        <div className="logo3d-front">
          <img src={VROCHE_LOGO_SRC} alt="Vroche logo" className="logo-front-image" />
        </div>
        <div className="logo3d-shine" />
      </div>
      <div className="logo3d-shadow" />
    </div>
  );
}
function PhoneMockup() {
  return (
    <div className="product-preview mx-auto mt-2 w-full max-w-xs" aria-hidden="true">
      <div className="relative mx-auto w-[220px] overflow-hidden rounded-[2.8rem] border border-white/[0.12] bg-[#0a120e] shadow-[0_40px_100px_rgba(0,0,0,0.55)]" style={{ aspectRatio: "9/19.5" }}>
        <div className="absolute inset-0 flex flex-col p-3">
          <div className="mb-3 flex items-center justify-between px-1">
            <span className="text-[10px] font-semibold text-white/50" style={{ fontFamily: "Roboto, sans-serif" }}>9:41</span>
            <div className="flex gap-1"><div className="h-1.5 w-1.5 rounded-full bg-white/40" /><div className="h-1.5 w-3 rounded-full bg-white/40" /><div className="h-1.5 w-4 rounded-full bg-white/40" /></div>
          </div>
          <div className="relative mb-3 overflow-hidden rounded-2xl bg-gradient-to-b from-[#63D7B1]/20 to-[#040806]" style={{ height: "38%" }}>
            <div className="absolute inset-0 flex items-center justify-center"><img src={VROCHE_LOGO_SRC} alt="" style={{ width: 56, height: 56, objectFit: "contain", opacity: 0.85 }} /></div>
            <div className="absolute bottom-2 left-3 right-3 flex items-end justify-between">
              <div><p className="text-[9px] font-bold uppercase tracking-[0.18em] text-white/40" style={{ fontFamily: "DM Sans" }}>VIRTUAL TRY-ON</p><p className="text-xs font-extrabold text-white" style={{ fontFamily: "DM Sans" }}>Outfit del día</p></div>
              <div className="rounded-full bg-[#63D7B1] px-2.5 py-1 text-[9px] font-bold uppercase tracking-[0.15em] text-[#040806]">AI</div>
            </div>
          </div>
          <div className="mb-2 grid grid-cols-2 gap-2" style={{ height: "28%" }}>
            {["Casuals", "Formal"].map(label => (
              <div key={label} className="overflow-hidden rounded-xl border border-white/[0.08] bg-white/[0.05]">
                <div className="flex h-full flex-col items-center justify-center p-2">
                  <div className="mb-1 h-6 w-6 rounded-lg bg-[#63D7B1]/20" />
                  <p className="text-[9px] font-semibold text-white/60" style={{ fontFamily: "DM Sans" }}>{label}</p>
                </div>
              </div>
            ))}
          </div>
          <div className="mt-4 flex items-center justify-between rounded-[1.4rem] border border-white/[0.08] bg-white/[0.04] px-4 py-3">
            <span className="text-xs text-white/[0.65]" style={{ fontFamily: "Roboto, sans-serif" }}>Smart styling in one app</span>
            <span className="rounded-full bg-[#63D7B1] px-3 py-1 text-[10px] font-bold uppercase tracking-[0.16em] text-[#040806]">Beta</span>
          </div>
        </div>
      </div>
    </div>
  );
}
function MiniSignalStrip() {
  return (
    <div className="mini-signal mobile-hero-cards mx-auto mt-12 grid max-w-3xl grid-cols-2 gap-3 md:grid-cols-4">
      {[["AI", "Stylist"], ["VTO", "Try-on"], ["Closet", "Digital"], ["Social", "Community"]].map(([title, subtitle]) => (
        <div key={title} className="rounded-2xl border border-white/10 bg-white/[0.045] px-4 py-3 backdrop-blur-xl">
          <p className="font-subtitle text-lg font-extrabold text-white">{title}</p>
          <p className="font-body mt-1 text-[11px] uppercase tracking-[0.22em] text-white/[0.38]">{subtitle}</p>
        </div>
      ))}
    </div>
  );
}

// ─── Main Landing Page ────────────────────────────────────────────────────────
export default function VrocheLandingPage() {
  const [email, setEmail] = useState("");
  const [submittedEmail, setSubmittedEmail] = useState("");
  const [legalPage, setLegalPage] = useState(null); // 'privacy' | 'terms' | 'legal' | 'cookies' | null

  const features = useMemo(() => [
    { icon: CameraIcon, title: "Virtual try-on sobre tu foto", text: "Prueba prendas y looks sobre tu foto para decidir mejor antes de ponértelo o comprarlo." },
    { icon: Wand2Icon, title: "AI Stylist personal", text: "Looks recomendados según tu estilo, la ocasión, el clima y lo que ya tienes en tu armario.", accent: "coral" },
    { icon: ShirtIcon, title: "Armario digital inteligente", text: "Sube tus prendas, clasifícalas y convierte tu armario en algo útil, visual y accionable." },
    { icon: CalendarDaysIcon, title: "Planificación de looks", text: "Prepara outfits para universidad, trabajo, viajes, cenas o cualquier evento.", accent: "coral" },
    { icon: SocialIcon, title: "Red social de estilo", text: "Comparte looks, recibe votos, comentarios y descubre inspiración real de otros usuarios." },
    { icon: LockIcon, title: "Privacidad desde el diseño", text: "Tus fotos, tus prendas y tus preferencias deben estar bajo control del usuario.", accent: "coral" },
  ], []);

  const steps = [
    { number: "01", title: "Escanea tu armario", text: "Sube prendas desde fotos o enlaces y organízalas en tu armario digital.", icon: ScanLineIcon },
    { number: "02", title: "Dale contexto", text: "Indica el plan, la ocasión, el tiempo o el tipo de estilo que buscas.", icon: Layers3Icon },
    { number: "03", title: "Prueba y decide", text: "Visualiza propuestas, ajusta opciones, comparte y guarda tus looks favoritos.", icon: SmartphoneIcon },
  ];

  const useCases = ["No sé qué ponerme hoy", "Quiero comprar mejor", "Tengo un evento y necesito ideas", "Quiero aprovechar más mi armario", "Voy de viaje y necesito outfits", "Quiero validar un look antes de salir"];

  function handleSubmit(event) {
    event.preventDefault();
    if (!isValidWaitlistEmail(email)) return;
    setSubmittedEmail(email.trim());
  }

  return (
    <>
      {/* Cookie Banner */}
      <CookieBanner onOpenPolicy={() => setLegalPage("cookies")} />

      {/* Legal Modal */}
      {legalPage && <LegalModal page={legalPage} onClose={() => setLegalPage(null)} />}

      <main className="min-h-screen overflow-hidden bg-[#FCFFFE] text-[#040806] selection:bg-[#63D7B1] selection:text-[#040806]" data-testid="vroche-landing">
        <style>{`
          @import url('https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700;800&family=DM+Serif+Display:ital@0;1&family=Roboto:wght@300;400;500;700&display=swap');
          .font-title { font-family: 'DM Serif Display', serif; font-style: italic; }
          .font-subtitle { font-family: 'DM Sans', sans-serif; }
          .font-body { font-family: 'Roboto', sans-serif; }
          html { scroll-behavior: smooth; }
          @keyframes fadeUp { from { opacity: 0; transform: translateY(22px); } to { opacity: 1; transform: translateY(0); } }
          @keyframes scatterDrift { 0%, 100% { transform: translate(-50%, -50%) rotate(var(--rotation, 0deg)); } 50% { transform: translate(calc(-50% + var(--drift-x, 0px)), calc(-50% + var(--drift-y, 0px))) rotate(calc(var(--rotation, 0deg) + 5deg)); } }
          @keyframes heroFloat { 0%, 100% { translate: 0 0; } 50% { translate: 0 -10px; } }
          @keyframes orbitSpinA { from { transform: rotateX(68deg) rotateZ(0deg); } to { transform: rotateX(68deg) rotateZ(360deg); } }
          @keyframes orbitSpinB { from { transform: rotateY(74deg) rotateZ(360deg); } to { transform: rotateY(74deg) rotateZ(0deg); } }
          @keyframes particleFloat { 0%,100% { transform: translate3d(0,0,0) scale(1); opacity: .55; } 50% { transform: translate3d(16px,-16px,0) scale(1.18); opacity: 1; } }
          .fade-up { animation: fadeUp .8s ease-out both; }
          .logo-reveal-field { --reveal-x: -9999px; --reveal-y: -9999px; --reveal-size: 175px; --reveal-opacity: 0; }
          .logo-noise-layer, .logo-reveal-layer { position: absolute; inset: 0; }
          .logo-noise-wrap { position: absolute; width: auto; max-width: none; transform-origin: center; animation: scatterDrift var(--drift-duration, 16s) ease-in-out var(--drift-delay, 0s) infinite; pointer-events: none; user-select: none; }
          .logo-noise-img { display: block; height: 100%; width: auto; max-width: none; object-fit: contain; object-position: center; pointer-events: none; user-select: none; }
          .logo-noise-img-base { filter: grayscale(1) blur(3.8px) saturate(.45) contrast(.95); opacity: 1; mix-blend-mode: screen; }
          .logo-noise-img-reveal { filter: brightness(0) saturate(100%) invert(81%) sepia(31%) saturate(565%) hue-rotate(96deg) brightness(92%) contrast(90%) drop-shadow(0 0 10px rgba(99,215,177,.45)); opacity: 1; mix-blend-mode: screen; }
          .logo-noise-fallback { height: 100%; aspect-ratio: 1 / 1; color: rgba(255,255,255,0.20); filter: blur(3.8px) grayscale(1) saturate(.35); }
          .logo-noise-fallback-reveal { color: #63D7B1; filter: drop-shadow(0 0 12px rgba(99,215,177,.45)); }
          .logo-reveal-layer { opacity: var(--reveal-opacity); -webkit-mask-image: radial-gradient(circle var(--reveal-size) at var(--reveal-x) var(--reveal-y), #000 0%, #000 52%, rgba(0,0,0,.55) 64%, transparent 81%); mask-image: radial-gradient(circle var(--reveal-size) at var(--reveal-x) var(--reveal-y), #000 0%, #000 52%, rgba(0,0,0,.55) 64%, transparent 81%); transition: opacity .16s ease; }
          .logo3d-root { --shine-x: 50%; --shine-y: 50%; --glow-x: 50%; --glow-y: 50%; --glow-opacity: 0.85; perspective: 1500px; }
          .logo3d-global-aura { position: absolute; left: var(--glow-x); top: var(--glow-y); width: 335px; height: 335px; border-radius: 9999px; transform: translate(-50%, -50%); background: radial-gradient(circle, rgba(99,215,177,.30) 0%, rgba(99,215,177,.14) 36%, rgba(99,215,177,.04) 58%, rgba(99,215,177,0) 78%); filter: blur(18px); opacity: var(--glow-opacity); transition: left .08s linear, top .08s linear, opacity .18s ease; pointer-events: none; }
          .logo3d-object { position: relative; width: min(420px, 76vw); height: min(420px, 76vw); transform-style: preserve-3d; will-change: transform; animation: heroFloat 6s ease-in-out infinite; }
          .logo3d-depth-stack, .logo3d-front { position: absolute; inset: 0; display: flex; align-items: center; justify-content: center; transform-style: preserve-3d; }
          .logo3d-front { transform: translateZ(72px); }
          .logo-front-image, .logo-depth-image { position: absolute; inset: 0; width: 100%; height: 100%; object-fit: contain; object-position: center; user-select: none; pointer-events: none; }
          .logo-front-image { filter: drop-shadow(0 34px 60px rgba(0,0,0,.34)) drop-shadow(0 0 26px rgba(99,215,177,.22)); }
          .logo-depth-image { filter: brightness(.35) saturate(1.1) drop-shadow(0 2px 0 rgba(99,215,177,.08)); }
          .logo3d-shine { position: absolute; left: var(--shine-x); top: var(--shine-y); z-index: 4; width: 175px; height: 175px; border-radius: 999px; transform: translate(-50%, -50%) translateZ(96px); background: radial-gradient(circle, rgba(255,255,255,.30) 0%, rgba(255,255,255,.14) 30%, rgba(255,255,255,0) 68%); filter: blur(10px); mix-blend-mode: screen; pointer-events: none; transition: left .08s linear, top .08s linear; }
          .logo3d-shadow { position: absolute; left: 50%; bottom: -26px; width: 60%; height: 15%; transform: translateX(-50%) rotateX(86deg) translateZ(-90px); border-radius: 999px; background: rgba(0,0,0,.44); filter: blur(22px); }
          .logo3d-orbit { position: absolute; width: min(430px, 82vw); height: min(430px, 82vw); border-radius: 9999px; border: 1px solid rgba(255,255,255,.13); pointer-events: none; }
          .logo3d-orbit-a { animation: orbitSpinA 18s linear infinite; box-shadow: 0 0 60px rgba(99,215,177,.10); }
          .logo3d-orbit-b { width: min(318px, 64vw); height: min(318px, 64vw); border-color: rgba(255,87,51,.17); animation: orbitSpinB 14s linear infinite; }
          .logo3d-particle { position: absolute; width: 10px; height: 10px; border-radius: 999px; background: ${BRAND.mint}; box-shadow: 0 0 22px rgba(99,215,177,.8); animation: particleFloat 5s ease-in-out infinite; }
          .particle-a { left: 18%; top: 28%; }
          .particle-b { right: 17%; top: 24%; background: ${BRAND.coral}; box-shadow: 0 0 22px rgba(255,87,51,.75); animation-delay: .8s; }
          .particle-c { left: 22%; bottom: 22%; animation-delay: 1.4s; }
          .particle-d { right: 23%; bottom: 25%; width: 7px; height: 7px; animation-delay: 1.9s; }
          @media (max-width: 1024px) { .tablet-hero-inner { padding-top: 18px; padding-bottom: 86px; } .tablet-hero-grid { grid-template-columns: 1fr; gap: 42px; } .tablet-feature-grid { grid-template-columns: repeat(2, minmax(0, 1fr)); } .tablet-section-title { font-size: clamp(54px, 8vw, 78px); } }
          @media (max-width: 768px) { body { overflow-x: hidden; } .logo-reveal-field { --reveal-size: 108px; } .logo-noise-wrap:nth-child(n+45) { display: none; } .logo-noise-img-base { filter: grayscale(1) blur(2.4px) saturate(.42) contrast(.96); } .mobile-hero-section { min-height: auto; } .mobile-header { padding: 16px 18px; gap: 12px; align-items: center; } .mobile-header-logo { height: 38px; min-width: 0; } .mobile-header-logo-img { height: 30px; max-width: 132px; } .mobile-header-cta { min-height: 38px; padding-left: 14px; padding-right: 14px; border-radius: 999px; font-size: 10px; letter-spacing: .16em; } .mobile-hero-inner { padding-left: 18px; padding-right: 18px; padding-top: 10px; padding-bottom: 64px; } .mobile-hero-grid { display: block; } .mobile-hero-copy-block { text-align: center; margin-left: auto; margin-right: auto; } .mobile-eyebrow { max-width: 100%; white-space: normal; justify-content: center; font-size: 10px; letter-spacing: .12em; padding: 8px 11px; line-height: 1.55; } .mobile-hero-title { margin-top: 20px; font-size: clamp(45px, 15.5vw, 66px); line-height: .87; letter-spacing: -0.058em; text-align: center; } .mobile-hero-copy { margin: 22px auto 0; font-size: 15px; line-height: 1.75; max-width: 34rem; text-align: center; } .mobile-form { margin: 24px auto 0; padding: 8px; border-radius: 22px; gap: 8px; width: 100%; max-width: 430px; } .mobile-input { min-height: 50px; border-radius: 16px; font-size: 14px; width: 100%; text-align: center; } .mobile-submit { min-height: 50px; border-radius: 16px; width: 100%; font-size: 12px; } .mini-signal { display: none; } .product-preview { display: none; } .mobile-section { padding-left: 18px; padding-right: 18px; padding-top: 64px; padding-bottom: 64px; } .mobile-section-tight { padding-bottom: 64px; } .mobile-section-title { font-size: clamp(40px, 12.5vw, 56px); line-height: .92; letter-spacing: -0.045em; } .mobile-section-copy { font-size: 15px; line-height: 1.75; } .mobile-pill-row { gap: 8px; margin-top: 28px; } .mobile-pill-row span { font-size: 12px; padding: 8px 11px; } .mobile-card { border-radius: 24px; padding: 20px; } .mobile-icon-box { height: 42px; width: 42px; border-radius: 14px; margin-bottom: 18px; } .mobile-card-title { font-size: 18px; } .mobile-card-text { font-size: 13px; line-height: 1.65; } .mobile-feature-grid { grid-template-columns: 1fr; gap: 14px; } .mobile-dark-grid { display: block; } .mobile-dark-grid > * + * { margin-top: 28px; } .mobile-dark-cards { grid-template-columns: 1fr; gap: 12px; } .mobile-step-grid { grid-template-columns: 1fr; gap: 14px; } .mobile-vision-grid { grid-template-columns: 1fr; gap: 28px; } .mobile-vision-card { border-radius: 28px; padding: 22px; } .mobile-vision-card .grid { grid-template-columns: 1fr; } .mobile-waitlist-title { font-size: clamp(42px, 13.5vw, 62px); } .mobile-footer-inner { align-items: flex-start; gap: 18px; } }
          @media (max-width: 420px) { .mobile-header { padding-left: 14px; padding-right: 14px; } .mobile-header-logo-img { height: 27px; max-width: 116px; } .mobile-header-cta { min-height: 34px; padding-left: 12px; padding-right: 12px; font-size: 10px; } .mobile-hero-inner, .mobile-section { padding-left: 14px; padding-right: 14px; } .mobile-hero-title { font-size: clamp(42px, 14.2vw, 58px); } .mobile-hero-copy, .mobile-section-copy { font-size: 14px; } .mobile-section-title { font-size: clamp(36px, 12vw, 50px); } .mobile-card { padding: 18px; } }
          @media (max-width: 360px) { .mobile-header-logo-img { height: 25px; max-width: 104px; } .mobile-header-cta { padding-left: 10px; padding-right: 10px; } .mobile-hero-title { font-size: 40px; } .mobile-eyebrow { font-size: 9px; } }
        `}</style>

        <LogoRevealBackground />

        <section className="mobile-hero-section relative overflow-hidden bg-[#040806] text-white">
          <div className="absolute inset-0 overflow-hidden">
            <div className="absolute left-1/2 top-[-120px] h-[540px] w-[540px] -translate-x-1/2 rounded-full bg-[#63D7B1]/18 blur-[120px]" />
            <div className="absolute right-[-80px] top-[180px] h-[380px] w-[380px] rounded-full bg-[#FF5733]/12 blur-[110px]" />
            <div className="absolute left-[-100px] bottom-[40px] h-[320px] w-[320px] rounded-full bg-white/[0.06] blur-[100px]" />
            <div className="absolute inset-0 opacity-[0.16]" style={{ backgroundImage: "linear-gradient(rgba(252,255,254,0.10) 1px, transparent 1px), linear-gradient(90deg, rgba(252,255,254,0.10) 1px, transparent 1px)", backgroundSize: "42px 42px" }} />
          </div>
          <header className="mobile-header relative z-20 mx-auto flex max-w-7xl items-center justify-between px-6 py-7 lg:px-8">
            <a href="#top" className="flex items-center gap-3"><HeaderLogo /></a>
            <NavChipGroup />
            <a href="#waitlist" className="mobile-header-cta rounded-[1rem] border border-white/10 bg-white/[0.06] px-5 py-3 text-sm font-bold text-white backdrop-blur-xl transition hover:bg-white/[0.12]" style={{ fontFamily: "DM Sans" }}>Beta</a>
          </header>
          <div id="top" className="mobile-hero-inner tablet-hero-inner relative z-10 mx-auto max-w-7xl px-6 pb-24 pt-6 lg:px-8 lg:pb-32 lg:pt-10">
            <div className="mobile-hero-grid tablet-hero-grid grid items-center gap-14 lg:grid-cols-[1.1fr_0.9fr]">
              <div className="mobile-hero-copy-block fade-up text-left">
                <Badge><span className="h-2 w-2 rounded-full bg-[#63D7B1]" />AI FASHION · VIRTUAL TRY-ON · SMART CLOSET · SOCIAL</Badge>
                <h1 className="mobile-hero-title font-title mt-8 max-w-5xl text-6xl leading-[0.9] tracking-[-0.05em] text-white md:text-8xl">Your wardrobe,<span className="block text-[#63D7B1]">upgraded by AI.</span></h1>
                <p className="mobile-hero-copy font-body mt-8 max-w-2xl text-lg leading-8 text-white/[0.68] md:text-xl md:leading-9">Vroche transforma tu armario en una experiencia inteligente: prueba looks sobre tu foto, recibe recomendaciones de estilo, comparte outfits y planifica qué ponerte para cada momento.</p>
                <form onSubmit={handleSubmit} className="mobile-form mt-10 flex w-full max-w-2xl flex-col gap-3 rounded-[1.8rem] border border-white/10 bg-white/[0.07] p-3 backdrop-blur-xl sm:flex-row">
                  <input value={email} onChange={(event) => setEmail(event.target.value)} type="email" placeholder="Introduce tu correo" className="mobile-input font-body min-h-14 flex-1 rounded-[1.2rem] border border-white/10 bg-white px-5 text-sm text-[#040806] outline-none placeholder:text-black/35" data-testid="hero-email" />
                  <button type="submit" className="mobile-submit font-subtitle inline-flex min-h-14 items-center justify-center gap-2 rounded-[1.2rem] bg-[#63D7B1] px-7 text-sm font-extrabold uppercase tracking-[0.14em] text-[#040806] transition hover:scale-[1.02] hover:bg-[#79e3c2]" data-testid="hero-submit">Acceso beta<ArrowRightIcon className="h-4 w-4" /></button>
                </form>
                {submittedEmail ? <p className="font-body mt-4 text-sm text-[#63D7B1]" role="status">Gracias. {submittedEmail} ya está en la beta de Vroche.</p> : <p className="font-body mt-4 text-sm text-white/40">Sé de los primeros en probar Vroche y ayudarnos con feedback real.</p>}
                <MiniSignalStrip />
              </div>
              <div className="fade-up"><Global3DVrocheLogo /><PhoneMockup /></div>
            </div>
          </div>
        </section>

        <section className="mobile-section relative -mt-1 bg-[#FCFFFE] px-6 py-24 lg:px-8">
          <div className="relative z-10 mx-auto max-w-7xl">
            <div className="grid gap-8 lg:grid-cols-[0.9fr_1.1fr] lg:items-end">
              <div><SectionLabel>El problema</SectionLabel><h2 className="mobile-section-title font-title text-5xl leading-[0.95] tracking-[-0.04em] md:text-7xl">Tenemos más ropa que nunca, pero decidimos peor.</h2></div>
              <p className="mobile-section-copy font-body max-w-2xl text-lg leading-9 text-black/60">El usuario compra por impulso, repite outfits, olvida prendas que ya tiene y necesita inspiración visual inmediata. Vroche une moda, inteligencia artificial y experiencia social para resolver ese momento diario: "¿qué me pongo?".</p>
            </div>
            <div className="mobile-pill-row mt-12 flex flex-wrap gap-3">{useCases.map((item) => <Pill key={item}>{item}</Pill>)}</div>
          </div>
        </section>

        <section id="product" className="mobile-section mobile-section-tight relative bg-[#FCFFFE] px-6 pb-28 lg:px-8">
          <div className="relative z-10 mx-auto max-w-7xl">
            <div className="mb-14 max-w-3xl"><SectionLabel>Producto</SectionLabel><h2 className="mobile-section-title font-title text-5xl leading-[0.95] tracking-[-0.04em] md:text-7xl">Una app de moda con cerebro tech.</h2><p className="mobile-section-copy font-body mt-6 text-lg leading-8 text-black/60">Diseñada para que el usuario pase de la duda a la decisión: escanear, combinar, probar, compartir y comprar mejor.</p></div>
            <div className="mobile-feature-grid tablet-feature-grid grid gap-6 md:grid-cols-2 lg:grid-cols-3" data-testid="features-grid">{features.map((feature) => <FeatureCard key={feature.title} {...feature} />)}</div>
          </div>
        </section>

        <section className="mobile-section relative overflow-hidden bg-[#040806] px-6 py-28 text-white lg:px-8">
          <div className="absolute left-0 top-0 h-96 w-96 rounded-full bg-[#63D7B1]/20 blur-[100px]" />
          <div className="absolute bottom-0 right-0 h-96 w-96 rounded-full bg-[#FF5733]/20 blur-[100px]" />
          <div className="mobile-dark-grid relative z-10 mx-auto grid max-w-7xl gap-12 lg:grid-cols-[1fr_1fr] lg:items-center">
            <div><SectionLabel>Experiencia</SectionLabel><h2 className="mobile-section-title font-title max-w-3xl text-5xl leading-[0.95] tracking-[-0.04em] text-white md:text-7xl">De inspiración a decisión en segundos.</h2><p className="mobile-section-copy font-body mt-6 max-w-xl text-lg leading-9 text-white/[0.62]">Vroche no quiere ser otra carpeta de inspiración. Quiere ser el sistema operativo de tu estilo: contexto, armario, recomendaciones y visualización en una misma experiencia.</p></div>
            <div className="mobile-dark-cards grid gap-4 sm:grid-cols-2">
              {[{ icon: ZapIcon, title: "Fast styling", text: "Looks generados al momento con criterios reales." }, { icon: ShoppingBagIcon, title: "Smart shopping", text: "Compra menos por impulso y más por encaje." }, { icon: CloudSunIcon, title: "Weather-aware", text: "Outfits adaptados al clima y al plan." }, { icon: SocialIcon, title: "Social proof", text: "Feedback y comunidad para validar tus looks." }].map((item) => <div key={item.title} className="mobile-card rounded-[2rem] border border-white/10 bg-white/[0.06] p-6 backdrop-blur-xl"><item.icon className="mb-5 h-6 w-6 text-[#63D7B1]" /><h3 className="font-subtitle mb-3 text-xl font-bold">{item.title}</h3><p className="font-body text-sm leading-7 text-white/[0.58]">{item.text}</p></div>)}
            </div>
          </div>
        </section>

        <section id="how" className="mobile-section relative bg-[#FCFFFE] px-6 py-28 lg:px-8">
          <div className="relative z-10 mx-auto max-w-7xl">
            <div className="mb-16 grid gap-8 lg:grid-cols-[0.9fr_1.1fr] lg:items-end"><div><SectionLabel>Cómo funciona</SectionLabel><h2 className="mobile-section-title font-title text-5xl leading-[0.95] tracking-[-0.04em] md:text-7xl">Simple para el usuario. Potente por debajo.</h2></div><p className="mobile-section-copy font-body max-w-2xl text-lg leading-9 text-black/60">La propuesta se apoya en visión artificial, recomendación contextual y una capa social que convierte el estilo personal en una experiencia práctica, visual y compartible.</p></div>
            <div className="mobile-step-grid grid gap-6 lg:grid-cols-3">{steps.map((step) => <div key={step.title} className="mobile-card relative overflow-hidden rounded-[2rem] border border-black/10 bg-white p-7 shadow-[0_20px_70px_rgba(4,8,6,0.07)]"><div className="mb-12 flex items-center justify-between"><span className="font-title text-6xl text-black/10">{step.number}</span><div className="mobile-icon-box flex h-12 w-12 items-center justify-center rounded-2xl bg-[#63D7B1]/20"><step.icon className="h-5 w-5 text-[#040806]" /></div></div><h3 className="mobile-card-title font-subtitle mb-4 text-2xl font-extrabold tracking-[-0.02em]">{step.title}</h3><p className="mobile-card-text font-body text-sm leading-7 text-black/[0.58]">{step.text}</p></div>)}</div>
          </div>
        </section>

        <section id="vision" className="mobile-section relative overflow-hidden px-6 py-28 lg:px-8" style={{ backgroundColor: BRAND.mint }}>
          <div className="absolute -right-20 top-0 h-80 w-80 rounded-full bg-white/35 blur-[80px]" />
          <div className="absolute -bottom-24 -left-20 h-80 w-80 rounded-full bg-[#FF5733]/25 blur-[80px]" />
          <div className="mobile-vision-grid relative z-10 mx-auto grid max-w-7xl gap-12 lg:grid-cols-[1.05fr_0.95fr] lg:items-center"><div><p className="font-subtitle mb-5 text-xs font-extrabold uppercase tracking-[0.3em] text-[#040806]/60">Visión Vroche</p><h2 className="mobile-section-title font-title text-5xl leading-[0.95] tracking-[-0.05em] text-[#040806] md:text-7xl">La nueva capa entre tu armario, tu identidad y la compra online.</h2></div><div className="mobile-vision-card rounded-[2.5rem] bg-[#040806] p-7 text-white shadow-[0_30px_90px_rgba(4,8,6,0.28)]"><p className="mobile-section-copy font-body text-lg leading-9 text-white/70">Vroche nace para una generación que decide en móvil, se inspira en redes y espera experiencias visuales inmediatas. La oportunidad está en unir utilidad diaria, AI personalizada y moda digital con una marca aspiracional.</p><div className="mt-8 grid gap-3 sm:grid-cols-3">{[["Daily", "uso recurrente"], ["Visual", "decisión rápida"], ["Social", "viralidad natural"]].map(([title, text]) => <div key={title} className="rounded-3xl border border-white/10 bg-white/[0.06] p-4"><p className="font-subtitle text-lg font-extrabold text-[#63D7B1]">{title}</p><p className="font-body mt-1 text-xs text-white/50">{text}</p></div>)}</div></div></div>
        </section>

        <section id="waitlist" className="mobile-section relative overflow-hidden bg-[#040806] px-6 py-28 text-white lg:px-8">
          <div className="absolute inset-0"><div className="absolute left-1/2 top-0 h-[520px] w-[520px] -translate-x-1/2 rounded-full bg-[#63D7B1]/20 blur-[120px]" /></div>
          <div className="relative z-10 mx-auto max-w-4xl text-center">
            <Badge className="mx-auto"><span className="h-2 w-2 rounded-full bg-[#FF5733]" />EARLY ACCESS</Badge>
            <h2 className="mobile-waitlist-title font-title mt-8 text-5xl leading-[0.92] tracking-[-0.05em] md:text-8xl">Be one of the first to wear the future.</h2>
            <p className="mobile-section-copy font-body mx-auto mt-7 max-w-2xl text-lg leading-9 text-white/[0.62]">Estamos preparando los primeros testers de Vroche. Queremos usuarios con criterio, feedback honesto y ganas de construir una experiencia de moda realmente útil.</p>
            <form onSubmit={handleSubmit} className="mobile-form mx-auto mt-10 flex max-w-xl flex-col gap-3 rounded-[2rem] border border-white/10 bg-white/[0.06] p-3 backdrop-blur-xl sm:flex-row">
              <input value={email} onChange={(event) => setEmail(event.target.value)} type="email" placeholder="tuemail@ejemplo.com" className="mobile-input font-body min-h-14 flex-1 rounded-full border border-white/10 bg-white px-5 text-sm text-[#040806] outline-none placeholder:text-black/35" data-testid="waitlist-email" />
              <button type="submit" className="mobile-submit font-subtitle inline-flex min-h-14 items-center justify-center gap-2 rounded-full bg-[#FF5733] px-7 text-sm font-extrabold uppercase tracking-[0.14em] text-white transition hover:scale-[1.02] hover:bg-[#ff6b4c]" data-testid="waitlist-submit">Join waitlist<ArrowRightIcon className="h-4 w-4" /></button>
            </form>
            {submittedEmail
              ? <p className="font-body mt-5 text-sm text-[#63D7B1]" role="status">Gracias. {submittedEmail} ya está apuntado a la waitlist de Vroche.</p>
              : <p className="font-body mt-5 text-xs text-white/[0.38]">Sin spam. Solo acceso, novedades clave y oportunidades para probar el producto antes del lanzamiento.</p>
            }
          </div>
        </section>

        {/* ── Footer with legal links ── */}
        <footer className="relative bg-[#040806] px-6 pb-10 text-white lg:px-8">
          <div className="mobile-footer-inner relative z-10 mx-auto flex max-w-7xl flex-col gap-6 border-t border-white/10 pt-8 md:flex-row md:items-center md:justify-between">
            <div className="flex items-center gap-3">
              <HeaderLogo />
              <span className="sr-only">Vroche</span>
            </div>
            <p className="font-body text-sm text-white/[0.42]">AI fashion app · Virtual try-on · Smart closet · Social styling</p>
            {/* Legal links */}
            <nav aria-label="Legal" className="flex flex-wrap items-center gap-x-5 gap-y-2">
              {[
                ["Aviso Legal", "legal"],
                ["Política de Privacidad", "privacy"],
                ["Términos y Condiciones", "terms"],
                ["Política de Cookies", "cookies"],
              ].map(([label, page]) => (
                <button
                  key={page}
                  onClick={() => setLegalPage(page)}
                  className="font-body text-xs text-white/[0.38] transition hover:text-white/70"
                  style={{ background: "none", border: "none", cursor: "pointer", padding: 0 }}
                >
                  {label}
                </button>
              ))}
            </nav>
          </div>
          <div className="relative z-10 mx-auto mt-6 max-w-7xl border-t border-white/[0.06] pt-5">
            <p className="font-body text-center text-[11px] text-white/[0.25]">
              © {new Date().getFullYear()} VROCHE APP S.L. · CIF B22761977 · Calle Don Abraham Quintanilla, 12, Madrid, España ·{" "}
              <a href={`mailto:${LEGAL.email}`} style={{ color: "rgba(252,255,254,0.35)", textDecoration: "none" }}>{LEGAL.email}</a>
            </p>
          </div>
        </footer>
      </main>
    </>
  );
}
